package com.cakes.mom.Service;

import org.springframework.stereotype.Service;

@Service
public class ProductService {
}
