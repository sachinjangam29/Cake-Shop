package com.cakes.mom.Controller;

import com.cakes.mom.DTO.ProductDTO;
import com.cakes.mom.Service.CategoryService;
import com.cakes.mom.model.Category;
import com.cakes.mom.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
public class AdminController {

    @Autowired
    private Category category;
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private Product product;

    @GetMapping("/admin")
    public String admin(){
        return "adminHome";
    }

    @GetMapping("/admin/categories")
    public String getAllCategories(Model model){
     model.addAttribute("categories", categoryService.getAllCategories());
        return "categories";
    }

    @GetMapping("/admin/categories/add")
    public String getACategory(Model model){
        model.addAttribute("category", category );
        return "categoriesAdd";
    }

    @PostMapping("/admin/categories/add")
    public String postACategory(@ModelAttribute("category") Category category){
        categoryService.addCategory(category);
        return "redirect:/admin/categories";
    }

    @GetMapping("/admin/categories/delete/{id}")
    public String deleteCategory(@PathVariable Integer id){
        categoryService.deleteCategory(id);
        return "redirect:/admin/categories";
    }

    @GetMapping("/admin/categories/update/{id}")
    public String updateCategory(@PathVariable Integer id, @ModelAttribute("category") Category category){
        categoryService.updateCategoryById(id,category);
        return "categoriesAdd";
    }

    @GetMapping("/admin/products")
    public String getAllProducts(){
        return "products";
    }

    @GetMapping("/admin/products/add")
    public String addAProduct(Model model){
    model.addAttribute("productDTO",new ProductDTO());

    return "productsAdd";
    }
}
